<?php
$Config['UserFilesPath'] = "/opensimwi/admin/upload/" ;
?>