﻿<TABLE cellSpacing=0 cellPadding=0 width=300 border=0>
  <TBODY>
  <TR>
    <TD vAlign=top align=right>
      <TABLE cellSpacing=0 cellPadding=0 width=300 border=0>
        <TBODY>
        <TR>
          <TD class=boxyellow_tl><IMG height=5 
            src="images/login_screens/icons/spacer.gif" width=5></TD>
          <TD class=boxyellow_t><IMG height=5 
            src="images/login_screens/icons/spacer.gif" width=5></TD>
          <TD class=boxyellow_tr><IMG height=5 
            src="images/login_screens/icons/spacer.gif" width=5></TD></TR>
        <TR>
          <TD class=boxyellow_l></TD>
          <TD class=black_content><IMG 
            src="images/login_screens/icons/alert.png" 
            align=absMiddle>&nbsp;<STRONG><?=$BOX_TITLE?></STRONG> 
            <DIV id=GREX style="MARGIN: 1px 0px 0px"><IMG 
            height=1 src="images/login_screens/icons/spacer.gif" 
width=1></DIV>
            <DIV class=boxtext>
            <P style="FONT-SIZE: 11px"><?=$BOX_INFOTEXT?></P></DIV></TD>
          <TD class=boxyellow_r></TD></TR>
        <TR>
          <TD class=boxyellow_bl></TD>
          <TD class=boxyellow_b></TD>
          <TD 
class=boxyellow_br></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>