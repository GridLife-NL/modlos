﻿<TABLE cellSpacing=0 cellPadding=0 width=300 border=0>
  <TBODY>
  <TR>
    <TD vAlign=top align=right>
      <TABLE cellSpacing=0 cellPadding=0 width=300 border=0>
        <TBODY>
        <TR>
          <TD class=boxgreen_tl><IMG height=5 
            src="images/login_screens/icons/spacer.gif" width=5></TD>
          <TD class=boxgreen_t><IMG height=5 
            src="images/login_screens/icons/spacer.gif" width=5></TD>
          <TD class=boxgreen_tr><IMG height=5 
            src="images/login_screens/icons/spacer.gif" width=5></TD></TR>
        <TR>
          <TD class=boxgreen_l></TD>
          <TD class=black_content><IMG 
            src="images/login_screens/icons/alert.png" 
            align=absMiddle>&nbsp;<STRONG><?=$BOX_TITLE?></STRONG> 
            <DIV id=GREX style="MARGIN: 1px 0px 0px"><IMG 
            height=1 src="images/login_screens/icons/spacer.gif" 
width=1></DIV>
            <DIV class=boxtext>
            <P style="FONT-SIZE: 11px"><?=$BOX_INFOTEXT?></P></DIV></TD>
          <TD class=boxgreen_r></TD></TR>
        <TR>
          <TD class=boxgreen_bl></TD>
          <TD class=boxgreen_b></TD>
          <TD 
class=boxgreen_br></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>